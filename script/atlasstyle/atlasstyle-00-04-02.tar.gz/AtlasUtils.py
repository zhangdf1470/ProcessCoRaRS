from ROOT import *
ROOT.gROOT.LoadMacro("AtlasUtils.C") 

